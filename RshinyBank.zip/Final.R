#Peter Iyawe
#Rshiny App
# Import libraries
library(shiny)
library(shinythemes)
library(data.table)
library(randomForest)
library(dplyr)
library(magrittr)
library(psych)
library(caret)
library(e1071)
library(car)
library(pROC)

library(dplyr)
library(tidyverse)
library(ggplot2)
library(scales)
library(plotly)
library(plyr)
#install.packages("ROSE")
library(ROSE)
library(randomForest)

# Read data
df1 <- read.csv("BankChurners_Small.csv")


#looking at details about the character type
glimpse(df1)


#Converting Variables to factors 
df1$Attrition_Flag <- factor(df1$Attrition_Flag)
df1$Gender <- factor(df1$Gender)
df1$Marital_Status <- factor(df1$Marital_Status)
df1$Education_Level <- factor(df1$Education_Level)
df1$Income_Category <- factor(df1$Income_Category)
glimpse(df1)


df_model<- df1%>%
select(Attrition_Flag,Customer_Age,Gender,Dependent_count,Marital_Status,Education_Level,
       Income_Category)

#No Issues with Multicollinarity all VIF scores below 10
vif(glm(formula=Attrition_Flag ~ . , family = binomial(link='logit'),data = df_model))

#I wanted to also run logistic regression
set.seed(100)
trainIndex <- createDataPartition(df_model$Attrition_Flag,
                                  p=0.75,
                                  list=FALSE,
                                  times=1)
# Create Training Data
df.train <- df_model[trainIndex,]


# Create Validation Data
df.valid <-df_model[-trainIndex,]




# Run a baseline model with the training dataset
baseline.model <- train(Attrition_Flag~.,
                        data=df.train,
                        method='glm',
                        family='binomial',
                        na.action=na.pass)

# View the model results
summary(baseline.model)

#Evaluation model performance using the validation dataset

#Criteria 1: the confusion matrix
predictionBl <- predict(baseline.model,newdata=df.valid)


confusionMatrix(predictionBl,df.valid$Attrition_Flag)

#Criteria 2: the ROC curve and area under the curve
pred.probabilitiesBl <- predict(baseline.model,newdata=df.valid,type='prob')

regression.ROCBl <- roc(predictor=pred.probabilitiesBl$`Attrited Customer`,
                      response=df.valid$Attrition_Flag,
                      levels=levels(df.valid$Attrition_Flag))
plot(regression.ROCBl)
regression.ROCBl$auc

# Build model Random Forest Model
modelRF <- randomForest(Attrition_Flag ~ ., data = df_model, ntree = 500, mtry =6 , importance = TRUE)

summary(modelRF)
#Evaluation model performance using the validation dataset

#Criteria 1: the confusion matrix
predictionRF <- predict(modelRF,newdata=df.valid)


confusionMatrix(predictionRF,df.valid$Attrition_Flag)


ui <- fluidPage(theme =shinythemes::themeSelector(),
  
  # Page header
  headerPanel('Will the customer Stay or leave?'),
  
  # Input values
  sidebarPanel(
    HTML("<h3>Variable Selection</h3>"),
    
    selectInput("Gender", label = "Gender:", 
                choices = list("Male" = "M", "Female" = "F"), 
                selected = "Male"),
    
    selectInput("Marital_Status", label = "Marital Status:",
                choices = list("Married" = "Married", "Single"= "Single", "Divorced" = "Divorced" ),
                selected = "single"),
    
    selectInput("Income_Category", label = "Income Range:",
                choices = list("Less than $40K" = "Less than $40K", "$40K - $60K"= "$40K - $60K",
                               "$60K - $80K" = "$60K - $80K","$80K - $120K" = "$80K - $120K",
                               "$120K +"= "$120K +" ),
                selected = "Less than $40K"),
    
    sliderInput("Customer_Age", "Age:",
                min = 15, max = 99,
                value = 30),
    
    sliderInput("Dependent_count", "Number of Children:",
                min = 0, max = 9,
                value = 1),
    
    selectInput("Education_Level", label = "Highest Education:", 
                choices = list("High School"="High School","Graduate"="Graduate",
                               "Uneducated"="Uneducated","College"="College",
                               "Post-Graduate"="Post-Graduate","Doctorate"="Doctorate"),
                selected = "Uneducated"),
    
    
    
    actionButton("submitbutton", "Submit", class = "btn btn-primary")
  ),
  
  mainPanel(
    tags$label(h3('Status/output')), # Status/Output Text Box
    verbatimTextOutput('contents'),
    dataTableOutput('tabledata') # Prediction results table
    
  )
)


server <- function(input, output, session) {

  # Input Data
  datasetInput <- reactive({  
    
  # Customer Age Gender Dependent Count ETC
    Name = c("Customer_Age",
             "Gender",
             "Dependent_count",
             "Marital_Status",
             "Education_Level",
             "Income_Category")
    Value = as.character(c(input$Customer_Age,
                           input$Gender,
                           input$Dependent_count,
                           input$Marital_Status,
                           input$Education_Level,
                           input$Income_Category))
    df <- data.frame(Name, Value,stringsAsFactors = FALSE)
  
  Attrition_Flag <- "Attrition_Flag"
  df <- rbind(df, Attrition_Flag)
  input <- t(df)
  #input Values Stored in an excel file that feeds into the Model 
  write.table(input,"input.csv",sep=",", quote = FALSE, row.names = FALSE, col.names = FALSE)
  #Assigning the imputed data to test object
  test <- read.csv(paste("input",".csv", sep=""), header = TRUE)
  
  #Converting the test objects to the correct data type
  test$Gender <- factor(test$Gender, levels = c("M", "F"))
  test$Attrition_Flag <- factor(test$Attrition_Flag, levels = c("Existing Customer", "Attrited Customer"))
  test$Marital_Status <- factor(test$Marital_Status, levels = c("Single", "Married", "Divorced"))
  test$Education_Level <- factor(test$Education_Level,levels = c("Uneducated","High School","College","Graduate","Post-Graduate","Doctorate"))
  test$Income_Category <- factor(test$Income_Category, levels=c("Less than $40K","$40K - $60K","$60K - $80K","$80K - $120K","$120K +"))
  # test$Customer_Age <- as.integer(test$Customer_Age)
  # test$Dependent_count <- as.integer(test$Dependent_count)
  
  #Predicting the results of the information the user selects 
  output <- data.frame(Prediction=predict(modelRF,test), round(predict(modelRF,test,type="prob"), 3))
  print(output)
  })
  
  # Status/Output Text Box
  output$contents <- renderPrint({
    if (input$submitbutton>0) { 
      isolate("Calculation complete.") 
    } else {
      return("Select Variables")
    }
  })
  
  # Prediction results table
  output$tabledata <- renderDataTable({
    if (input$submitbutton>0) { 
      isolate(datasetInput()) 
    } 
  })
  
}

####################################
# Create the shiny app             #
####################################
shinyApp(ui = ui, server = server)
